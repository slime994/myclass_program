close all; clear all;
n = 50; N = 1000;
%linspace(-3,3,n)は区間 [-3,3] 内の n 個の等間隔の点のベクトルを作成する。
x = linspace(0.1,10,n)'; X = linspace(0.1,10,N)';
pix = pi*x;
%「.」は要素単位で演算を行う
y = sin (pix)./(pix) + 0.1*x + 0.05*randn(n,1);
x2 = x.^2;
X2 = X.^2;
%hhは分散
hh = 2*0.3^2;
%lはl2正則化の制約の強さを変えるハイパーパラメータ
l = 0.1;
%k,Kはガウシアンカーネルを表す
k = exp(-(repmat(x2,1,n)+repmat(x2',n,1)-2*x*x')/hh);
K = exp(-(repmat(X2,1,n)+repmat(x2',N,1)-2*X*x')/hh);
t1 = k\y;
F1 = K*t1;
t2 = (k^2+l*eye(n))\(k*y);
F2 = K*t2;
figure(1);
hold on;
%axis([])は表示するグラフの軸
axis([0 10 -0.5 1.2]);
plot(X,F1,'g-');
plot(X,F2,'r--');
plot(x,y,'bo');
%legend('LS','l_2-Constrained LS');