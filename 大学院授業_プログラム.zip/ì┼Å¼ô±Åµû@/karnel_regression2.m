%close all; clear all;
len = length(traindata);
%linspace(-3,3,n)は区間 [-3,3] 内の n 個の等間隔の点のベクトルを作成する。
x = traindata(:,1); 
X = testdata;
%「.」は要素単位で演算を行う
y = traindata(:,2);
x2 = x.^2;
X2 = X.^2;
%hhは分散
hh = 2*0.5^2;
%lはl2正則化の制約の強さを変えるハイパーパラメータ
l = 1;
%k,Kはガウシアンカーネルを表す
k = exp(-(repmat(x2,1,len)+repmat(x2',len,1)-2*x*x')/hh);
K = exp(-(repmat(X2,1,len)+repmat(x2',len,1)-2*X*x')/hh);
%t1 = k\y;
%F1 = K*t1;
t2 = (k^2+l*eye(len))\(k*y);
F2 = K*t2;
figure(1);
hold on;
%axis([])は表示するグラフの軸
axis([-3 3 -3 3]);
%plot(X,F1,'g-');
plot(X,F2,'r--');
plot(x,y,'bo');
%legend('LS','l_2-Constrained LS');